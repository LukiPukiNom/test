# Paradise Hub
### Paradise Hub is not your usual roblox script hub, our hub is completely free and open sourced for users to learn from! We strive to bring the best features and content! 

### Script:
`loadstring(game:HttpGet("https://raw.githubusercontent.com/Valenity/ParadiseHub-Open-Source/main/FuckCheater.Fun!"))()`

## View our supported games and their features below!
* Halloween Night
   - Trick-or-Treating
     - Knock on Random Door
     - Collect all Candy
     - Teleport to Sell Area
* Slime Tower Tycoon
   - Main Menu
     - Grab Orbs
     - Deposit Orbs
   - Slime Menu
     - Merge Slimes
   - Travel Menu
     - Travel to Obby
     - Travel to Realms
     - Travel to Plot
     - Travel to Hall of Fame
   - Shop Menu
     - Purchase Slimes (Flexible Number)
     - Purchase Rate
   - Misc Menu
     - Remove Ads
     - Remove In-App Purchases
* Idle Heroes
   - Attack Menu
     - Attack Current Enemy
   - Level Menu
     - Last Level
     - Next Level
* Robowling
   - Main Menu
     - Grab Coins
   - Game Menu
     - Instantly Start Game
   - Teleport Menu
     - Players
* Theme Park Tycoon 2
   - Main Menu
     - Clean Trash
     - Change Park Name
   - Teleport Menu
     - Players
   - Custom UI Settings
     - Show Default Cursor
* Merge Simulator
   - Main Menu
     - Merge Blocks
   - Teleport Menu
     - Players
   - Misc Menu
     - Give 2x Frenzy
* Racing Rocket
   - Speed Menu
     - Manipulate Clicks
   - Teleport Menu
     - Players
   - Misc Menu
     - Manipulate Reward Stars
* Lemonade Tycoon
   - Remove Package
     - Remove Weird Group Package
   - Codes
     - Redeem All Known Codes
   - Lemonade Production
     - Harvest Trees
     - Make Lemonade
* Truck Factory Tycoon
   - Tycoon Menu
     - Auto Purchase Buttons
     - Auto Collect Cash
   - Teleport Menu
     - Players
* High School Life
   - Game Menu
     - Change Team
     - Change Persona (Name, Description)
   - Teleport Menu
     - Players


# Common Questions
> Why did you go from paid to free and open source?
#### I figured it was the best way to properly get out there as a struggling developer, and I figured people could also build and learn off of what I create and provide to the community.

> Did the people who purchased in the past get ripped off in the end?
#### Of course not! I always find ways to give back and compensate where it's due. We don't believe in taking money from other's as that promotes the worst evil in all of internet marketplaces, scamming.

> Do you plan on actually pursuing this as a main project?
#### With all of my other projects either being cancelled due to boredom or lack of funding, Paradise Hub will remain on the list until funding is gone (more than likely will happen) or Paradise Hub is merged with another hub (more than likely will not happen)

